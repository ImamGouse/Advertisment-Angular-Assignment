export class User {
    Constructor(  
        public Title: string,
        public Name: string,
        public Category: string,
        public Description: string,
    ){}
}
